import os
import pytest

os.environ["FLASK_SECRET_KEY"] = "test"
os.environ["DATABASE_URL"] = "sqlite:///:memory:"
os.environ["ADMIN_USERNAME"] = "admin"
os.environ["ADMIN_PASSWORD"] = "pass"

from app import create_app, db, Message

@pytest.fixture()
def client():
    app = create_app()
    app.config.update(TESTING=True, WTF_CSRF_ENABLED=False)
    with app.app_context():
        db.create_all()
    return app.test_client()

def test_home(client):
    assert client.get("/").status_code == 200

def test_contact_saves_message(client):
    r = client.post("/contact", data={
        "name": "A",
        "email": "a@example.com",
        "subject": "Hi",
        "message": "Test message",
        "website": ""
    }, follow_redirects=True)
    assert r.status_code == 200
    with client.application.app_context():
        assert Message.query.count() == 1

def test_admin_login_redirects(client):
    r = client.post("/admin/login", data={"username":"admin", "password":"pass"}, follow_redirects=False)
    assert r.status_code in (302, 303)
