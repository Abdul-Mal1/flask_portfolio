import os
from datetime import datetime

from flask import (
    Flask, render_template, request, redirect, url_for, flash,
    send_from_directory, jsonify
)
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import (
    LoginManager, UserMixin, login_user, login_required, logout_user
)
from werkzeug.security import generate_password_hash, check_password_hash
from flask_wtf import CSRFProtect
from flask_talisman import Talisman

db = SQLAlchemy()
migrate = Migrate()
login_manager = LoginManager()
csrf = CSRFProtect()

from time import time
RATE_LIMIT = {}  # ip -> [timestamps]


def is_rate_limited(ip: str, limit: int = 5, window_seconds: int = 60) -> bool:
    now = time()
    timestamps = RATE_LIMIT.get(ip, [])
    timestamps = [t for t in timestamps if now - t < window_seconds]
    if len(timestamps) >= limit:
        RATE_LIMIT[ip] = timestamps
        return True
    timestamps.append(now)
    RATE_LIMIT[ip] = timestamps
    return False


def normalize_database_url(url: str | None) -> str | None:
    if url and url.startswith("postgres://"):
        return url.replace("postgres://", "postgresql://", 1)
    return url


class User(db.Model, UserMixin):
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    def set_password(self, password: str) -> None:
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)


class Message(db.Model):
    __tablename__ = "messages"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    email = db.Column(db.String(320), nullable=False)
    subject = db.Column(db.String(200))
    message = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    ip = db.Column(db.String(64))
    user_agent = db.Column(db.String(400))


def ensure_admin_user():
    """Create an admin user if ADMIN_USERNAME/ADMIN_PASSWORD are set and user doesn't exist."""
    username = os.getenv("ADMIN_USERNAME")
    password = os.getenv("ADMIN_PASSWORD")
    if not username or not password:
        return
    existing = User.query.filter_by(username=username).first()
    if existing:
        return
    u = User(username=username)
    u.set_password(password)
    db.session.add(u)
    db.session.commit()


def create_app() -> Flask:
    app = Flask(__name__)
    app.secret_key = os.getenv("FLASK_SECRET_KEY", "change-this-in-production")

    database_url = normalize_database_url(os.getenv("DATABASE_URL"))
    if not database_url:
        database_url = "sqlite:///app.db"

    app.config.update(
        SQLALCHEMY_DATABASE_URI=database_url,
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
    )

    # Security headers (CSP disabled for simplicity; enable later if needed)
    Talisman(app, content_security_policy=None)

    db.init_app(app)
    migrate.init_app(app, db)
    csrf.init_app(app)

    login_manager.init_app(app)
    login_manager.login_view = "admin_login"

    with app.app_context():
        db.create_all()
        ensure_admin_user()

    register_routes(app)
    return app


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))


def register_routes(app: Flask) -> None:
    @app.route("/")
    def home():
        return render_template("index.html")

    @app.route("/resume")
    def resume():
        filename = "Resume.pdf"
        asset_dir = os.path.join(app.root_path, "static", "assets")
        path = os.path.join(asset_dir, filename)
        if not os.path.exists(path):
            flash("Resume file not found. Add static/assets/Resume.pdf", "warning")
            return redirect(url_for("home") + "#resume")
        return send_from_directory(asset_dir, filename, as_attachment=True)

    @app.route("/contact", methods=["POST"])
    def contact():
        name = (request.form.get("name") or "").strip()
        email = (request.form.get("email") or "").strip()
        subject = (request.form.get("subject") or "").strip()
        body = (request.form.get("message") or "").strip()

        # Honeypot (bots)
        website = (request.form.get("website") or "").strip()
        if website:
            return ("", 204)

        ip = request.headers.get("X-Forwarded-For", request.remote_addr) or "unknown"
        if is_rate_limited(ip):
            flash("Too many messages. Please wait a minute and try again.", "warning")
            return redirect(url_for("home") + "#contact")

        if not name or not email or not body:
            flash("Please fill in name, email, and message.", "error")
            return redirect(url_for("home") + "#contact")

        msg = Message(
            name=name,
            email=email,
            subject=subject,
            message=body,
            ip=ip,
            user_agent=(request.headers.get("User-Agent", "")[:400]),
        )
        db.session.add(msg)
        db.session.commit()

        flash("Message sent! I’ll get back to you soon.", "success")
        return redirect(url_for("home") + "#contact")

    # -------- Admin --------
    @app.route("/admin/login", methods=["GET", "POST"])
    def admin_login():
        if request.method == "POST":
            username = (request.form.get("username") or "").strip()
            password = (request.form.get("password") or "").strip()
            user = User.query.filter_by(username=username).first()
            if not user or not user.check_password(password):
                flash("Invalid username or password.", "error")
                return redirect(url_for("admin_login"))
            login_user(user)
            return redirect(url_for("admin_dashboard"))
        return render_template("admin_login.html")

    @app.route("/admin/logout")
    @login_required
    def admin_logout():
        logout_user()
        flash("Logged out.", "success")
        return redirect(url_for("home"))

    @app.route("/admin")
    @login_required
    def admin_dashboard():
        q = (request.args.get("q") or "").strip()
        query = Message.query
        if q:
            like = f"%{q}%"
            query = query.filter(
                db.or_(
                    Message.name.ilike(like),
                    Message.email.ilike(like),
                    Message.subject.ilike(like),
                    Message.message.ilike(like),
                )
            )
        messages = query.order_by(Message.id.desc()).limit(200).all()
        return render_template("admin.html", messages=messages, q=q)

    @app.route("/admin/export.csv")
    @login_required
    def admin_export_csv():
        import csv
        from io import StringIO
        si = StringIO()
        writer = csv.writer(si)
        writer.writerow(["id", "created_at", "name", "email", "subject", "message", "ip", "user_agent"])
        for m in Message.query.order_by(Message.id.desc()).all():
            writer.writerow([
                m.id,
                m.created_at.isoformat(),
                m.name,
                m.email,
                m.subject or "",
                m.message,
                m.ip or "",
                m.user_agent or ""
            ])
        output = si.getvalue()
        return app.response_class(
            output,
            mimetype="text/csv",
            headers={"Content-Disposition": "attachment; filename=messages.csv"},
        )

    # -------- Health / SEO --------
    @app.route("/health")
    def health():
        return jsonify({"status": "ok"})

    @app.route("/robots.txt")
    def robots():
        return app.response_class(
            "User-agent: *\nAllow: /\nSitemap: /sitemap.xml\n",
            mimetype="text/plain",
        )

    @app.route("/sitemap.xml")
    def sitemap():
        base = request.url_root.rstrip("/")
        pages = [f"{base}/"]
        now = datetime.utcnow().date().isoformat()
        xml = [
            "<?xml version=\"1.0\" encoding=\"UTF-8\"?>",
            "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">",
        ]
        for p in pages:
            xml.append("<url>")
            xml.append(f"<loc>{p}</loc>")
            xml.append(f"<lastmod>{now}</lastmod>")
            xml.append("</url>")
        xml.append("</urlset>")
        return app.response_class("\n".join(xml), mimetype="application/xml")


app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=True)
